<!DOCTYPE html>
<html>
<head>
	<title>Tip_Calculation</title>
	<link rel="stylesheet" href="calculator_style.css">
	<style> p{font-size: 1.5em;}</style>
	<meta name="generator" content="BBEdit 13.1" />
</head>

<body>
	<h1> W's Winery and Vineyard</h1>
	<?php
		# get the values of the bill and percentage selcected
		$bill = $_POST['check'];
		$percent = $_POST['tip'];
		
		# calculate the tip and final amount
		$tip = $bill * ($percent / 100);
		$total = $tip + $bill;
		
		#format the values
		$bill = number_format($bill, 2);
		$tip = number_format($tip, 2);
		$total = number_format($total, 2); 
		
		echo"<p><em>Bill Amount:</em> $$bill</p>";
	
		echo"<p>Tip Percentage: $percent%</p>";
	
		echo"<p>Tip Amount: $$tip</p>";
	
		echo"<p><strong>Total Amount: </strong>$$total</p>";
	?>
</body>
</html>


