<?php
	// create scession and get names of user
	session_start();
	$_SESSION['userName'] = $_POST["name"];
?>
<html>
<head>
	<title>Lab 4</title>
	<style>
	
		label {
		float: left; 
		clear: left;
		margin-top: 15px;
		width: 180px:
		}
		label:nth-of-type(2) { 
		margin-bottom: 10px;
		margin-top: 10px;
		width: 150px:
		}
		
		input[type ="password"] {
		float: left; 
		margin-top: 15px;
		width: 150px:
		}
		
		input[type ="submit"] {
		float: left; 
		clear: left;
		margin-left: 150px;
		margin-top: 15px
		}
		
		.error{
		clear: left;
		color: red;
		font-weight: bold;
		margin-left: 10px
		}
		
	</style>	
</head>

<body>
	<?php
		// unfilled name and password error variables
		$err = " ";
		$errname = "";

		//
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			// password, cornfirmed password, and name varables
			// are gathered from post
			$pw1 = $_POST["pw1"];
			$pw2 = $_POST["pw2"];
			$name = $_POST["name"];
			
			// checks if name is entered
			if(empty($name) == true){
				$errname = "please enter name";
			}
			// if name is entered, determine if the password is 
			// efficent 
			else{
				// determines if passwords match
				if(strcmp($pw1,$pw2) != 0){
					$err = "passwords do not match";
				}
				
				// determines if passwords aren't empty
				else if(empty($pw1) == true && empty($pw2) == true){
					$err = "password is empty";
				}
				
				// determines if the password meets the required length 
				else if(strlen($pw1) < 8){
					$err = "password is not long enough";
				}
				
				// determines if the password has a upper case value
				else if(preg_match('/[A-Z]/',$pw1) != 1){
					$err = "password does not contain a upper case";
				}
				
				// determines if the password has a lower case value 
				else if(preg_match('/[a-z]/',$pw1) != 1){
					$err = "password does not contain a lower case";
				}
				
				// determines if hte passowrd has a numeric value 
				else if(preg_match('/[0-9]/',$pw1) != 1){
					$err = "password does not contain a number";
				}
				// if all requirements are met, the success page is loaded
				else{
					 
					header("Location: lab4success.php");
					exit;
				}
			}
		}
	?>
	<form action ="lab4form.php" method="post">
		<label for="name">Name</label>
		<input id="name" name="name" type="text" value="<?php echo $name;?>"/>
		<label class="error"><?php echo $errname;?></label>
		
		<label for = "pw1">New Password</label>
		<input type ="password" name = "pw1" id="pw1" value="<?php echo $pw1;?>"/>
		
		<label for = "pw2">Re-enter New Password</label>
		<input type ="password" name = "pw2" id="pw2"value="<?php echo $pw2;?>"/>
		<label class="error"><?php echo $err;?></label>
	<input id="button" type="submit" value="Submit"/>
	</form>
	<p><?php echo $msg;?></p>
</body>
</html>