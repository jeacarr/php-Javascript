<?php
	// get the userName from pervious page
	session_start();
	$user = $_SESSION['userName'];
?>
<html>
<head>
	<title>Success</title>
	<style>
		p{
			color: purple;
			clear: both;
			margin-top: 10px;
		}
		
	</style>	
</head>

<body>
	<p>Congratulations <?php echo $user?>, you have successfully changed your password!</p>
</body>
</html>