<!DOCTYPE html>
<?php
	// create scession and get name for order
	session_start();
	include "bagelWitch_header.php";
	$name = $_SESSION['orderName']; 
	$finalOrder = $_SESSION['getOrder'];
	
?>
<html>

<body>

	<?php
		// collect the final total of the order
		$finalCost = 0;
		echo "<i>Order Summary for " . $name ." ". date("M.d.Y") . "</i><br>" ;
		
		foreach($finalOrder as $type => $price) {
  			// if the price of an item doesn't cost anything, still include it on the order
  			if(is_numeric($price) == true && $price == 0){
  				echo"<p>" . $type. " $0.00</p>";
  			}
  			// if the price is greater than zero add it onto the order and the finalCost calcuator
  			else if(is_numeric($price) == true){	
  				$finalCost += $price;
  				echo "<p>" . $type." $". number_format($price, 2)."</p>";
  			}
  			// if the item is sliced or toasted, move on.
  			else{
 		 		echo "<p><small>" . $type. "</small></p>";
  			}		
		}
		echo "<strong>Total $". number_format($finalCost, 2)."</strong>";
	?>
</body>
<?php
	include "bagelWitch_footer.php";
?>
</html>
