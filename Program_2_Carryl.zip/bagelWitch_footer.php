<!DOCTYPE html>
<html>
<footer>
The Bagel Witch &#183; 1 First Street &#183; Raleigh, NC 27607 &#169; <?php echo date("Y");?>
</footer>
</html>
