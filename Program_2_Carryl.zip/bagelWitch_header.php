<!DOCTYPE html>
<html>
<head>
	<title>The Bagel Witch</title>
	<link rel="stylesheet" href="bagelWitch_style.css">
</head>
<div>
	<h1>The Bagel Witch</h1>
	<h2>"where special orders do upset us"</h2>
	<h1>Bagel Box Builder</h1>
</div>
</html>
